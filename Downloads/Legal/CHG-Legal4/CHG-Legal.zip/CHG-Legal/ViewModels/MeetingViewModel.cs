﻿using System.ComponentModel.DataAnnotations;

namespace CHG_Legal.ViewModels
{
    public class MeetingViewModel
    {
        public int? Id { get; set; }

        [Required(ErrorMessage = "التاريخ مطلوب")]
        public string Date { get; set; }

        [Required(ErrorMessage = "نوع الاجتماع مطلوب")]
        public string Type { get; set; }

        [Required(ErrorMessage = "الاجتماع بخصوص مطلوب")]
        public string About { get; set; }

        [Required(ErrorMessage = "موضوع الاجتماع مطلوب")]
        public string Subject { get; set; }

        [Required(ErrorMessage = "حالة الاجتماع مطلوبة")]
        public string Status { get; set; }

        public string Notes { get; set; }
    }
}
