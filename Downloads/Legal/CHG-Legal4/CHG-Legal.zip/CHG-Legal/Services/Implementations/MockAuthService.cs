﻿using CHG_Legal.Services.Interfaces;

namespace CHG_Legal.Services.Implementations
{
    public class MockAuthService : IAuthService
    {
        // أي اسم مستخدم وكلمة سر صحيحة
        public Task<bool> ValidateUserAsync(string username, string password)
        {
            // للتبسيط، أي بيانات تدخل صحيحة
            return Task.FromResult(true);
        }
    }
}
