﻿using CHG_Legal.Models;
using CHG_Legal.Services.Interfaces;

namespace CHG_Legal.Services.Implementations
{
    public class MockMeetingService : IMeetingService
    {
        private static List<Meeting> _meetings = new List<Meeting>
        {
            new Meeting { Id = 1, Date = "2026-03-10", Type = "مجلس إدارة", Subject = "اعتماد الميزانية", Status = "approved", About = "CHC", Notes = "" },
            new Meeting { Id = 2, Date = "2026-03-15", Type = "جمعية عمومية", Subject = "تقرير الأداء السنوي", Status = "rejected", About = "CHS", Notes = "" },
            new Meeting { Id = 3, Date = "2026-03-20", Type = "مجلس إدارة", Subject = "مناقشة التوسعات", Status = "approved", About = "CHC", Notes = "" }
        };
        private static int _nextId = 4;

        public Task<List<Meeting>> GetAllMeetingsAsync()
        {
            return Task.FromResult(_meetings);
        }

        public Task<Meeting> AddMeetingAsync(Meeting meeting)
        {
            meeting.Id = _nextId++;
            _meetings.Add(meeting);
            return Task.FromResult(meeting);
        }

        public Task<bool> UpdateMeetingAsync(Meeting meeting)
        {
            var existing = _meetings.FirstOrDefault(m => m.Id == meeting.Id);
            if (existing == null) return Task.FromResult(false);

            existing.Date = meeting.Date;
            existing.Type = meeting.Type;
            existing.Subject = meeting.Subject;
            existing.Status = meeting.Status;
            existing.About = meeting.About;
            existing.Notes = meeting.Notes;
            return Task.FromResult(true);
        }

        public Task<bool> DeleteMeetingAsync(int id)
        {
            var existing = _meetings.FirstOrDefault(m => m.Id == id);
            if (existing == null) return Task.FromResult(false);
            _meetings.Remove(existing);
            return Task.FromResult(true);
        }
    }

}
