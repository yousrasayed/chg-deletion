﻿using CHG_Legal.Models;

namespace CHG_Legal.Services.Interfaces
{
    public interface IMeetingService
    {

        Task<List<Meeting>> GetAllMeetingsAsync();
        Task<Meeting> AddMeetingAsync(Meeting meeting);
        Task<bool> UpdateMeetingAsync(Meeting meeting);
        Task<bool> DeleteMeetingAsync(int id);
    }
}
