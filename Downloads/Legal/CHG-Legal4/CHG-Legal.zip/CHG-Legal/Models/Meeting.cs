namespace CHG_Legal.Models
{
    public class Meeting
    {
        public int Id { get; set; }
        public string Date { get; set; } 
        public string Type { get; set; } 
        public string Subject { get; set; }
        public string Status { get; set; } 
        public string About { get; set; }
        public string Notes { get; set; }
        // لاستقبال الملفات المرفوعة
        public List<IFormFile> Attachments { get; set; }
    }

}
