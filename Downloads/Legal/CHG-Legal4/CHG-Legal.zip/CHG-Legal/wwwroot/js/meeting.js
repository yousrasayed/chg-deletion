﻿//$(document).ready(function () {
//    // تعيين التوكن لجميع طلبات AJAX
//    $.ajaxSetup({
//        headers: {
//            'RequestVerificationToken': window.antiForgeryToken
//        }
//    });

//    let meetings = [];
//    let filters = { type: '', about: '', subject: '', date: '' };
//    let editingId = null;

//    // Load meetings from server
//    function loadMeetings() {
//        $.get('@Url.Action("GetMeetings", "Meetings")', function (data) {
//            meetings = data;
//            renderTable();
//        }).fail(function (xhr) {
//            console.log('Load error:', xhr.responseText);
//            alert('فشل في تحميل البيانات');
//        });
//    }

//    // Render table
//    function renderTable() {
//        const filtered = meetings.filter(m => {
//            return (!filters.type || m.type === filters.type) &&
//                (!filters.about || m.about === filters.about) &&
//                (!filters.subject || (m.subject && m.subject.includes(filters.subject))) &&
//                (!filters.date || m.date === filters.date);
//        });

//        let html = '';
//        filtered.forEach((m, index) => {
//            const rowClass = m.status === 'approved' ? 'table-success-row' : 'table-danger-row';
//            const typeColor = m.type === 'مجلس إدارة' ? 'text-danger' : 'text-success';
//            html += `<tr class="${rowClass}" data-id="${m.id}">
//                        <td>${index + 1}</td>
//                        <td>${m.date}</td>
//                        <td class="${typeColor}">${m.type}</td>
//                        <td>${m.subject}</td>
//                        <td>${m.about}</td>
//                        <td>
//                            <div class="d-flex gap-2">
//                                <span class="action-icons action-edit" onclick="editMeeting(${m.id})"><i class="fas fa-edit"></i></span>
//                                <span class="action-icons action-download"><i class="fas fa-download"></i></span>
//                                <span class="action-icons action-print"><i class="fas fa-print"></i></span>
//                                <span class="action-icons action-delete" onclick="deleteMeeting(${m.id})"><i class="fas fa-trash-alt"></i></span>
//                            </div>
//                        </td>
//                        <td>
//                            <button class="btn w-100 btn-teal">الموافقات</button>
//                        </td>
//                    </tr>`;
//        });
//        $('#tableBody').html(html);
//    }

//    // Delete function
//    window.deleteMeeting = function (id) {
//        if (!confirm('هل أنت متأكد من الحذف؟')) return;
//        $.get('@Url.Action("DeleteMeeting", "Meetings")' + '?id=' + id, function () {
//            meetings = meetings.filter(m => m.id !== id);
//            renderTable();
//        }).fail(function (xhr) {
//            console.log('Delete error:', xhr.responseText);
//            alert('فشل في الحذف');
//        });
//    };

//    // Edit function
//    window.editMeeting = function (id) {
//        const meeting = meetings.find(m => m.id === id);
//        if (!meeting) return;

//        $('#meetingDate').val(meeting.date);
//        $('#meetingType').val(meeting.type);
//        $('#meetingAbout').val(meeting.about);
//        $('#meetingSubject').val(meeting.subject);
//        $('#meetingStatus').val(meeting.status);
//        $('#meetingNotes').val(meeting.notes);
//        $('#meetingFile').val('');

//        editingId = id;
//        $('#modalTitle').text('تعديل الاجتماع');
//        $('#addEditMeetingModal').modal('show');
//    };

//    // Filter events
//    $('#filterType, #filterAbout, #filterDate, #filterSearchBtn').on('change click', function () {
//        filters.type = $('#filterType').val();
//        filters.about = $('#filterAbout').val();
//        filters.subject = $('#filterSubject').val();
//        filters.date = $('#filterDate').val();
//        renderTable();
//    });

//    $('#filterSubject').on('input', function () {
//        filters.subject = $(this).val();
//        renderTable();
//    });

//    // Add button
//    $('#addMeetingBtn').on('click', function () {
//        $('#meetingDate').val('');
//        $('#meetingType').val('');
//        $('#meetingAbout').val('');
//        $('#meetingSubject').val('');
//        $('#meetingStatus').val('');
//        $('#meetingNotes').val('');
//        $('#meetingFile').val('');

//        editingId = null;
//        $('#modalTitle').text('إضافة اجتماع');
//        $('#addEditMeetingModal').modal('show');
//    });

//    // Save button
//    $('#saveMeetingBtn').on('click', function () {
//        const date = $('#meetingDate').val();
//        const type = $('#meetingType').val();
//        const about = $('#meetingAbout').val();
//        const subject = $('#meetingSubject').val();
//        const status = $('#meetingStatus').val();

//        if (!date || !type || !about || !subject || !status) {
//            alert('الرجاء ملء جميع الحقول المطلوبة');
//            return;
//        }

//        const meetingData = {
//            date: date,
//            type: type,
//            about: about,
//            subject: subject,
//            status: status,
//            notes: $('#meetingNotes').val()
//        };

//        if (editingId !== null) {
//            // Update
//            meetingData.id = editingId;
//            $.ajax({
//                url: '@Url.Action("UpdateMeeting", "Meetings")',
//                type: 'POST',
//                contentType: 'application/json',
//                data: JSON.stringify(meetingData),
//                success: function (updated) {
//                    const index = meetings.findIndex(m => m.id === updated.id);
//                    if (index !== -1) meetings[index] = updated;
//                    renderTable();
//                    $('#addEditMeetingModal').modal('hide');
//                },
//                error: function (xhr) {
//                    console.log('Update error:', xhr.responseText);
//                    alert('فشل في التحديث');
//                }
//            });
//        } else {
//            // Add
//            $.ajax({
//                url: '@Url.Action("AddMeeting", "Meetings")',
//                type: 'POST',
//                contentType: 'application/json',
//                data: JSON.stringify(meetingData),
//                success: function (created) {
//                    meetings.push(created);
//                    renderTable();
//                    $('#addEditMeetingModal').modal('hide');
//                },
//                error: function (xhr) {
//                    console.log('Add error:', xhr.responseText);
//                    alert('فشل في الإضافة');
//                }
//            });
//        }
//    });

//    // Reset editingId when modal is hidden
//    $('#addEditMeetingModal').on('hidden.bs.modal', function () {
//        editingId = null;
//    });

//    // Initial load
//    loadMeetings();
//});


$(document).ready(function () {

    // تعيين التوكن لجميع طلبات AJAX
    $.ajaxSetup({
        headers: {
            'RequestVerificationToken': window.antiForgeryToken
        }
    });

    let meetings = [];
    let filters = { type: '', about: '', subject: '', date: '' };
    let editingId = null;
    window.addAttachment = function () {

        const container = document.getElementById("attachmentContainer");

        if (!container) {
            console.error("attachmentContainer not found");
            return;
        }

        const newRow = document.createElement("div");

        newRow.className = "attachment-row";

        newRow.innerHTML = `
        <input type="file" name="attachments" class="file-upload id="meetingFile"">

        <button type="button"
                class="btn btn-danger"
                onclick="this.parentNode.remove()">
            حذف
        </button>
    `;

        container.appendChild(newRow);
    };
    // Load meetings from server
    function loadMeetings() {
        $.get('/Meetings/GetMeetings', function (data) {
            meetings = data;
            renderTable();
        }).fail(function (xhr) {
            console.log('Load error:', xhr.responseText);
            alert('فشل في تحميل البيانات');
        });
    }

    // Render table
    function renderTable() {

        const filtered = meetings.filter(m => {
            return (!filters.type || m.type === filters.type) &&
                (!filters.about || m.about === filters.about) &&
                (!filters.subject || (m.subject && m.subject.includes(filters.subject))) &&
                (!filters.date || m.date === filters.date);
        });

        let html = '';

        filtered.forEach((m, index) => {

            const rowClass = m.status === 'approved'
                ? 'table-success-row'
                : 'table-danger-row';

            const typeColor = m.type === 'مجلس إدارة'
                ? 'text-danger'
                : 'text-success';

            html += `
                <tr class="${rowClass}" data-id="${m.id}">
                    <td>${index + 1}</td>
                    <td>${m.date}</td>
                    <td class="${typeColor}">${m.type}</td>
                    <td>${m.subject}</td>
                    <td>${m.about}</td>

                    <td>
                        <div class="d-flex gap-2">

                            <span class="action-icons action-edit"
                                  onclick="editMeeting(${m.id})">
                                  <i class="fas fa-edit"></i>
                            </span>

                            <span class="action-icons action-download">
                                  <i class="fas fa-download"></i>
                            </span>

                            <span class="action-icons action-print">
                                  <i class="fas fa-print"></i>
                            </span>

                            <span class="action-icons action-delete"
                                  onclick="deleteMeeting(${m.id})">
                                  <i class="fas fa-trash-alt"></i>
                            </span>

                        </div>
                    </td>

                    <td>
                        <button class="btn w-100 btn-teal">
                            الموافقات
                        </button>
                    </td>
                </tr>
            `;
        });

        $('#tableBody').html(html);
    }
      // وظائف تجريبية للتحميل والطباعة
            window.downloadMeeting = function(id) {
                // يمكنك استدعاء API لتحميل ملفات الاجتماع
                toastr.info('سيتم التحميل قريباً...');
            };

            window.printMeeting = function(id) {
                // يمكنك فتح نافذة طباعة لتقرير الاجتماع
                toastr.info('سيتم الطباعة قريباً...');
            };

            // وظيفة الموافقات
            window.approvalsMeeting = function(id) {
                toastr.info('سيتم فتح صفحة الموافقات...');
            };

    // Delete meeting
    window.deleteMeeting = function (id) {

        if (!confirm('هل أنت متأكد من الحذف؟'))
            return;

        $.get('/Meetings/DeleteMeeting?id=' + id, function () {

            meetings = meetings.filter(m => m.id !== id);

            renderTable();

        }).fail(function (xhr) {

            console.log('Delete error:', xhr.responseText);
            alert('فشل في الحذف');

        });
    };

    // Edit meeting
    window.editMeeting = function (id) {

        const meeting = meetings.find(m => m.id === id);

        if (!meeting) return;

        $('#meetingDate').val(meeting.date);
        $('#meetingType').val(meeting.type);
        $('#meetingAbout').val(meeting.about);
        $('#meetingSubject').val(meeting.subject);
        $('#meetingStatus').val(meeting.status);
        $('#meetingNotes').val(meeting.notes);
        $('#meetingFile').val('');

        editingId = id;

        $('#modalTitle').text('تعديل الاجتماع');
        $('#addEditMeetingModal').modal('show');
    };

    // Filters
    $('#filterType, #filterAbout, #filterDate, #filterSearchBtn')
        .on('change click', function () {

            filters.type = $('#filterType').val();
            filters.about = $('#filterAbout').val();
            filters.subject = $('#filterSubject').val();
            filters.date = $('#filterDate').val();

            renderTable();
        });

    $('#filterSubject').on('input', function () {

        filters.subject = $(this).val();

        renderTable();
    });

    // Add button
    $('#addMeetingBtn').on('click', function () {

        $('#meetingDate').val('');
        $('#meetingType').val('');
        $('#meetingAbout').val('');
        $('#meetingSubject').val('');
        $('#meetingStatus').val('');
        $('#meetingNotes').val('');
        $('#meetingFile').val('');

        editingId = null;

        $('#modalTitle').text('إضافة اجتماع');

        $('#addEditMeetingModal').modal('show');
    });

    // Save meeting
    $('#saveMeetingBtn').on('click', function () {

        const date = $('#meetingDate').val();
        const type = $('#meetingType').val();
        const about = $('#meetingAbout').val();
        const subject = $('#meetingSubject').val();
        const status = $('#meetingStatus').val();

        if (!date || !type || !about || !subject || !status) {

            alert('الرجاء ملء جميع الحقول المطلوبة');

            return;
        }

        const meetingData = {

            date: date,
            type: type,
            about: about,
            subject: subject,
            status: status,
            notes: $('#meetingNotes').val()
        };

        // Update
        if (editingId !== null) {

            meetingData.id = editingId;

            $.ajax({

                url: '/Meetings/UpdateMeeting',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(meetingData),

                success: function (updated) {

                    const index =
                        meetings.findIndex(m => m.id === updated.id);

                    if (index !== -1)
                        meetings[index] = updated;

                    renderTable();

                    $('#addEditMeetingModal').modal('hide');
                },

                error: function (xhr) {

                    console.log('Update error:', xhr.responseText);

                    alert('فشل في التحديث');
                }

            });

        }

        // Add
        else {

            $.ajax({

                url: '/Meetings/AddMeeting',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify(meetingData),

                success: function (created) {

                    meetings.push(created);

                    renderTable();

                    $('#addEditMeetingModal').modal('hide');
                },

                error: function (xhr) {

                    console.log('Add error:', xhr.responseText);

                    alert('فشل في الإضافة');
                }

            });
        }
    });

    // Reset editingId
    $('#addEditMeetingModal').on('hidden.bs.modal', function () {

        editingId = null;

    });

    // First load
    loadMeetings();

});