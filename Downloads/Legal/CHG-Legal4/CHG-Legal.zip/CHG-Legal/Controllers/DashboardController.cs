﻿using Microsoft.AspNetCore.Mvc;

namespace CHG_Legal.Controllers
{
    public class DashboardController : Controller
    {
        public IActionResult Index()
        {
            // التحقق من الجلسة (يمكن استخدام Authorize attribute)
            if (HttpContext.Session.GetString("IsLoggedIn") != "true")
                return RedirectToAction("Login", "Account");
            return View();
        }
    }
}
