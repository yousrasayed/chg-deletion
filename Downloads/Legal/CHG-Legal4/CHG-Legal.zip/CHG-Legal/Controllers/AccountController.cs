using CHG_Legal.Models;
using CHG_Legal.Services.Interfaces;
using CHG_Legal.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;

namespace CHG_Legal.Controllers
{
    public class AccountController : Controller
    {
        private readonly IAuthService _authService;

        public AccountController(IAuthService authService)
        {
            _authService = authService;
        }

        [HttpGet]
        public IActionResult Login()
        {
            if (HttpContext.Session.GetString("IsLoggedIn") == "true")
                return RedirectToAction("Index", "Dashboard");
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Login(LoginViewModel model)
        {
            if (!ModelState.IsValid)
                return View(model);

            if (await _authService.ValidateUserAsync(model.Username, model.Password))
            {
                HttpContext.Session.SetString("IsLoggedIn", "true");
                HttpContext.Session.SetString("Username", model.Username);
                return RedirectToAction("Index", "Dashboard");
            }

            ModelState.AddModelError(string.Empty, "اسم المستخدم أو كلمة السر غير صحيحة");
            return View(model);
        }

        [HttpGet]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        }
    }
}
