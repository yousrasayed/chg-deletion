﻿using CHG_Legal.Models;
using CHG_Legal.Services.Interfaces;
using CHG_Legal.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace CHG_Legal.Controllers
{
    public class MeetingsController : Controller
    {
        private readonly IMeetingService _meetingService;

        public MeetingsController(IMeetingService meetingService)
        {
            _meetingService = meetingService;
        }

        // عرض الصفحة الرئيسية
        public async Task<IActionResult> Index()
        {
            if (HttpContext.Session.GetString("IsLoggedIn") != "true")
                return RedirectToAction("Login", "Account");

            // يمكن تحميل البيانات مباشرة أو عبر AJAX (سنستخدم AJAX)
            return View();
        }

        // لجلب جميع الاجتماعات (JSON)
        [HttpGet]
        public async Task<IActionResult> GetMeetings()
        {
            var meetings = await _meetingService.GetAllMeetingsAsync();
            return Json(meetings);
        }

        // لإضافة اجتماع
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddMeeting([FromBody] MeetingViewModel model)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var meeting = new Meeting
            {
                Date = model.Date,
                Type = model.Type,
                About = model.About,
                Subject = model.Subject,
                Status = model.Status,
                Notes = model.Notes
            };

            var created = await _meetingService.AddMeetingAsync(meeting);
            return Ok(created);
        }

        // لتعديل اجتماع
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> UpdateMeeting([FromBody] MeetingViewModel model)
        {
            if (!ModelState.IsValid || !model.Id.HasValue)
                return BadRequest(ModelState);

            var meeting = new Meeting
            {
                Id = model.Id.Value,
                Date = model.Date,
                Type = model.Type,
                About = model.About,
                Subject = model.Subject,
                Status = model.Status,
                Notes = model.Notes
            };

            var success = await _meetingService.UpdateMeetingAsync(meeting);
            if (success)
                return Ok(meeting);
            return NotFound();
        }

        // لحذف اجتماع
        [HttpGet]
        public async Task<IActionResult> DeleteMeeting(int id)
        {
            var success = await _meetingService.DeleteMeetingAsync(id);
            if (success)
                return Ok();
            return NotFound();
        }
    }
}
